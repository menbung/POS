package sw.pos;

public class Main {

	public static void main(String[] args) {
		Manager manager = new Manager();
		manager.menu();
	}

}
