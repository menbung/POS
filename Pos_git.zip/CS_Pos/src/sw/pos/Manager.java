package sw.pos;

public class Manager {
	public void menu() {
		Db db = new Db();
		//db.addProduct(new Product("BBAAAA", "��ī�ݶ�", "20201101", "2000"));
		//db.removeProduct("BBAAAA");
		//db.addNames("������");
		//db.addNames("��ī�ݶ�", "BBAA", 20);
		db.setCash(50000, 10, false);
		//db.removePayment("201025001", "AAAAAC");
		System.out.println("Done");
	}
}
